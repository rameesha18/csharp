using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using BookStoreApi.Data;
using Microsoft.EntityFrameworkCore;

namespace BookStoreApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<BookContext>(opt =>
                opt.UseInMemoryDatabase("BookList"));
            services.AddControllersWithViews(); // Use AddControllersWithViews for serving static files
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // Comment out or remove the following line to disable HTTPS redirection for development
            // app.UseHttpsRedirection();

            app.UseStaticFiles(); // Enable serving static files

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapFallbackToFile("index.html"); // Serve index.html for all unknown requests
            });
        }
    }
}
